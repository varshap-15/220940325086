package java_220940325086;

/*Q3 : Write a program to create a class named shape. In this class we have three
sub classes circle, triangle and square, each class has two member function
named draw () and erase (). Create these using Runtime Polymorphism concepts. (10 Marks)
*/

public class q3 

{
	public static void main(String[] args) {
		
		//object of subclasses		
		Circle c = new Circle();
		c.draw();
		c.erase();
		
		System.out.println("----------------------------------");
		
		Triangle t = new Triangle();
		t.draw();
		t.erase();
		
		System.out.println("----------------------------------");
		
		Square s = new Square();
		s.draw();
		s.erase();			
		
	}
	
	
}

class Shape  //parent class
{
	void draw()
	{
		System.out.println("this is draw function of shape class");
	}
	
	void erase()
	{
		System.out.println("this is erase function of shape class");
	}
}

class Circle extends Shape //subclass
{

	@Override				//overriding of draw method
	void draw() {
		System.out.println("this is draw function of circle class");
	}

	@Override				 //overriding of erase method
	void erase() {
		System.out.println("this is erase function of circle class");
	}
	
}

class Triangle extends Shape //subclass
{

	@Override
	void draw() {
		System.out.println("this is draw function of Triangle class");
	}

	@Override
	void erase() {
		System.out.println("this is erase function of Triangle class");
	}

}

class Square extends Shape //subclass
{

	@Override
	void draw() {
		System.out.println("this is draw function of Square class");
	}

	@Override
	void erase() {
		System.out.println("this is erase function of Square class");
	}
	
	
}