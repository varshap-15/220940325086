package java_220940325086;

import java.util.ArrayList;

/*Q1 : Write a Java program to create a new array list, add some elements (string) and print out 
 * the collection by using for-each loop. (10 Marks) 
 * 
 */


public class q1 
{
	public static void main(String[] args) 
	{
		ArrayList<String> strings = new ArrayList<String>();
		
		strings.add("one");
		strings.add("two");
		strings.add("three");
		strings.add("four");
		strings.add("five");
		
		for(String string : strings)
		{
			System.out.println(string);
		}
		
		
	}
}
