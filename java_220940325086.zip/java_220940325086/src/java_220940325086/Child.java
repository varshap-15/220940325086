package java_220940325086;

class GrandParent
{
	String grandFatherName;
	String grandMotherName;
	
	GrandParent(String grandFatherName,String grandMotherName)
	{
		this.grandFatherName=grandFatherName;
		this.grandMotherName=grandMotherName;
		System.out.println("grand Father Name=" + grandFatherName + ", grand Mother Name=" + grandMotherName);
		
	}
	
}

class Parent extends GrandParent
{	
	String fatherName;
	String motherName;
	
	Parent(String grandFatherName, String grandMotherName, String fatherName, String motherName) 
	{
		super(grandFatherName, grandMotherName);
		System.out.println("Father Name=" + fatherName + ", Mother Name=" + motherName);

	}
	
	Parent(String grandFatherName, String grandMotherName)
	{
		super(grandFatherName, grandMotherName);
	}

}




public class Child extends Parent 
{
	Child(String grandFatherName, String grandMotherName, String fatherName, String motherName) {
		super(grandFatherName, grandMotherName, fatherName, motherName);
		
	}
	
	public static void main(String[] args) {
		
		Child c = new Child("Amitabh","Jaya","Abhishek","Aishwarya");
	}
}

