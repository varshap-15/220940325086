package java_220940325086;

/*Q2 : Develop a class BankAccount having following data members : (10 Marks)
int accno
double balance
Write appropriate constructors to initialize data members
Define the following functions :
withdraw : balance will reduce
deposit : balance will increase
show : display accno and balance
If user tries to withdraw more than the balance, use exception handling code. Demonstrate the
concept of exception handling in main() function. 
*/

public class BankAccount 
{
	int accno;
	double balance;
	double withdrw;
	
	BankAccount(int accno,double balance)
	{
		this.accno=accno;
		this.balance=balance;
		
	}
	
	void withdraw(double withdrw) throws ExceptionAmountInvalid 
	{	
		this.withdrw=withdrw;
		if(this.withdrw>this.balance)
		{	
			
			throw new ExceptionAmountInvalid();
		}
		
		else
		{
			System.out.println("Successfully withraw");
		}
		
	}
	
	void deposit()
	{
		System.out.println("this is deposite function");
	}
	
	void show()
	{
		System.out.println("Info : 1. balance" +this.balance );
		System.out.println("		  accno" +this.accno );
	}
	
	public static void main(String[] args)
	{	
		BankAccount BA = new BankAccount(123456,500);
		
		try
		{	
			//calling risky method 
			BA.withdraw(600); // pass withdraw amount here 
						
		}
		
		catch(ExceptionAmountInvalid e)
		{
			System.out.println(e);
		}
	}
	
	
}

//exception class
class ExceptionAmountInvalid extends Exception
{
	ExceptionAmountInvalid()
	{
		super("withdraw amount is more than balance");
	}
}
